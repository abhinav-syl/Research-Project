def Hello(){
 print("Hello")
}
