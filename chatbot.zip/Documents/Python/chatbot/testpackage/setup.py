from setuptools import find_packages, setupsetup(
    name='testpackage',
    packages=find_packages(include=['mypythonlib']),
    version='0.1.0',
    description='My first Python library',
    author='Me',
    license='MIT',
)
