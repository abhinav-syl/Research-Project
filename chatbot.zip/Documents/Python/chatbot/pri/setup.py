from setuptools import find_packages, setupsetup(
    name='pri',
    packages=find_packages(include=['pri']),
    version='0.1.0',
    description='My first Python library',
    author='Me',
    license='MIT',
)
