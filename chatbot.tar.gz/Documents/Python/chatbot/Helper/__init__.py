from .func import remove_space 
from .func import word_to_int
from .func import to_one_hot
from .func import sent_to_words
from .func import max_length
from .func import sent_to_enc
from .func import filtering
from .func import unique_words