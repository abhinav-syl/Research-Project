from setuptools import find_packages, setupsetup(
    name='Helper',
    packages=find_packages(include=['Helper']),
    version='0.1.0',
    description='My first Python library',
    author='Me',
    license='MIT',
)
