from tensorflow import keras
#string as input, string as output
def remove_space(sample):
    sample_f=""
    for i in sample:
        if i=="\n":
            i = " "
        sample_f = sample_f+i
    return sample_f
    

#string input, string output
def filtering(sample):
    listw= sample.split(" ")
    listn=[]
    for i in listw:
        a = i
        flag=0
        if "." in a:
            b="."
            t = a.split(b)
            listn.append(t[0])
            flag=1
        
        elif  "," in a:
            b = ","
            t = a.split(b)
            listn.append(t[0])
            flag=1
        elif '"' in a:
            b='"'
            t = a.split(b)
            if t[0]=="":
                listn.append(t[1])
            else:
                listn.append(t[0])
            flag=1
        elif "/" in a:
            b="/"
            t = a.split(b)
            listn.append(t[0])
            listn.append(t[1])
            flag=1
        elif "?" in i:
            b = "?"
            t = a.split(b)
            listn.append(t[0])
            listn.append(t[1])
            t[1]=b
            flag=1
        
        elif "!" in a:
            b = "!"
            t = i.split(b)
            listn.append(t[0])
            listn.append(t[1])
            t[1]=b
            flag=1
        elif "-" in a:
            b = "-"
            t = i.split(b)
            listn.append(t[0])
            listn.append(t[1])
            t[1]=b
            flag=1

        if flag==0:
            listn.append(a)
    return listn          
    

def unique_words(sample_words):
    unique=[]
    for i in sample_words:
        if i not in unique:
            unique.append(i)
    return unique
    
def word_to_int(sample_words):
    length = len(sample_words)
    dic ={}
    dic[0] = ' '
    for i in range(0,length):
        dic[i+1]=sample_words[i]
    return dic
    
    
def to_one_hot(word_dico):
    import keras
    dic={}
    a=[]
    for i in range(0,len(word_dico)):
        a.append(i)
    one = keras.utils.to_categorical(a)
    for i in word_dico:
        dic[word_dico[int(i)]] = one[int(i)]
    return dic
    
def sent_to_words(x):
    listsw1=[]
    for i in x:
        b=[]
        a = filtering(i)
        listsw1.append(a)
    return listsw1
    
    
def max_length(x):
    maxl=0
    for i in x:
        if len(i)>maxl:
            maxl=len(i)
    return maxl
    
def sent_to_enc(sent,word_enc,lmax):
    #lmax = max_length(listsw)
    p1 = word_enc['legends'].shape[0]
    sent_enc=[]
    #print(sent)
    for i in sent:
        #print(i)
        sent_enc.append(word_enc[i])
    dif = lmax-len(sent_enc)
    for i in range(0,dif):
        sent_enc.append(word_enc[' '])
    return sent_enc
    
def to_input(list_sw,word_enc):
    lmax = 105
    inp=[]
    for i in list_sw:
        a = sent_to_enc(i,word_enc,lmax)
        inp.append(a)
    return inp
    
