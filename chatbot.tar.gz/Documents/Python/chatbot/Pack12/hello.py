def helloworld():
   print "hello"
